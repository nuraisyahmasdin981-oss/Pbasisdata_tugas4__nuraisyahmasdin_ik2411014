DELIMITER $$

CREATE PROCEDURE hitung_total()
BEGIN
    DECLARE v_counter INT DEFAULT 1;
    DECLARE v_total INT DEFAULT 0;

    WHILE v_counter <= 20 DO
        SET v_total = v_total + v_counter;
        SET v_counter = v_counter + 1;
    END WHILE;

    SELECT v_total AS total;
END$$

DELIMITER ;
DELIMITER $$

CREATE PROCEDURE bilangan_genap()
BEGIN
    DECLARE i INT DEFAULT 2;

    WHILE i <= 20 DO
        SELECT i AS bilangan_genap;
        SET i = i + 2;
    END WHILE;
END$$

DELIMITER ;
DELIMITER $$

CREATE PROCEDURE bilangan_genap()
BEGIN
    DECLARE i INT DEFAULT 2;

    WHILE i <= 20 DO
        SELECT i AS bilangan_genap;
        SET i = i + 2;
    END WHILE;
END$$

DELIMITER ;
DELIMITER $$

CREATE PROCEDURE total_belanja()
BEGIN
    DECLARE v_total INT DEFAULT 0;

    WHILE v_total < 500000 DO
        SET v_total = v_total + 50000;
        SELECT v_total AS total_belanja;
    END WHILE;
END$$

DELIMITER ;